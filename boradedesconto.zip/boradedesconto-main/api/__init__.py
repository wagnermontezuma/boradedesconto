"""
Pacote API do BoraDeDesconto.
""" 