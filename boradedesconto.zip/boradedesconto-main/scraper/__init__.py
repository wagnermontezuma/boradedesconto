"""
Pacote Scraper do BoraDeDesconto.
""" 