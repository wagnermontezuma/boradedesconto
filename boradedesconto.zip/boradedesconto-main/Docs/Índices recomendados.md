CREATE INDEX idx_discount ON offers(discount_pct);
CREATE INDEX idx_ts ON offers(ts DESC);
